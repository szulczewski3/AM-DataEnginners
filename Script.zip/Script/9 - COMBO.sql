ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY';


INSERT INTO COMBO
(CD_COMBO, NM_COMBO, INICIO_VND_COMBO, FIM_VND_COMBO, DS_COMBO, VL_COMBO, CATEGORIA_CD_CATEGORIA, PRODUTO_CD_PRODUTO)
VALUES
(001, 'COMBO DA GALERA',SYSDATE, NULL, '1-MUSSARELA, 
                                                     1-CALABRESA, 
                                                     1-PORTUGUESA, 
                                                     1-TOSCANA, 
                                                     1-PRESTIGIO. 
                                                     BEBIDAS NAO INCLUSAS',
 150.00,7, 31);
 