EXEC DBMS_RANDOM.SEED(681457802);
alter session set nls_date_format="dd/mm/yyyy";

-- Criando os Clientes
DECLARE
  cd_cliente_inicial INTEGER;
  seq_exists INTEGER;
  v_insert VARCHAR2(2000);
  
  TYPE NomeList IS VARRAY(879) OF VARCHAR2(40);
  nomes NomeList;
  
  TYPE SobreNomeList IS VARRAY(96) OF VARCHAR2(40);
  sobrenomes SobreNomeList;
  
  TYPE DominioList IS VARRAY(32) OF VARCHAR2(40);
  dominios DominioList;

  TYPE SexoList IS VARRAY(879) OF CHAR(1);
  sexos SexoList;
  
  v_random_primeiro INTEGER;
  v_random_segundo INTEGER;
 
BEGIN
  SELECT MAX(cd_cliente)+1 INTO cd_cliente_inicial
  FROM cliente;
  
  SELECT COUNT(*) INTO seq_exists
  FROM user_sequences
  WHERE sequence_name = 'SQ_CLIENTE';
  
  IF seq_exists = 1 THEN
    EXECUTE IMMEDIATE 'DROP SEQUENCE sq_cliente';
    --DBMS_OUTPUT.PUT_LINE('-- Dropou a Sequencia--');
  END IF;
  
  IF cd_cliente_inicial IS NULL THEN
    cd_cliente_inicial := 1;
  END IF;

  --DBMS_OUTPUT.PUT_LINE('-- Criando a Sequencia--');
  EXECUTE IMMEDIATE 'CREATE SEQUENCE sq_cliente START WITH '|| cd_cliente_inicial||' INCREMENT BY 1';
  
  nomes := NomeList('Paulo', 'Fernando', 'Aline', 'Amanda', 'Vanessa', 
					'Patricia', 'Mario', 'Thiago', 'Pedro', 'Lucas', 
					'Andre', 'Joao', 'Sophia', 'Sofia', 'Larissa', 
					'Giovanna', 'Juliana', 'Aparecida', 'Alexandre', 'Igor', 
					'Rafael', 'Gabriel', 'Robson', 'Oscar', 'Antonio', 
					'Jose', 'Severino', 'Maria', 'Joana', 'Claudia','Abigail',
          'Ab�lia','Abna','Ac�lia','�cil','A�ucena','Ada','Adalgisa','Ad�lia',
          'Adelaide','Adelinda','�dila','Ad�lia','Adosinda','Adriana','Afonsa','Afonsina',
          'Afra','Africana','�gata','Agna','Agnes','Agonia','Agripina','�gueda','Aida','Aid�',
          'Airiza','Aixa','Ala�de','Alana','Alba','Alberta','Albertina','Alcina','Alc�one','Alda',
          'Aldara','Aldenir','Aldenora','Aldina','Aldora','Alegria','Aleixa','Aleta','Alexa','Alexandra',
          'Al�xia','Alexina','Al�xis','Alfreda','�lia','Aliana','Ali�a','Alice','Al�cia','Alida','Alina','Aline',
          'Alisande','�lison','Alita','Alix','Alma','Almara','Almerinda','Almesinda','Almira','Altina','Alva','Alvarina',
          'Alzira','Amada','Am�lia','Amanda','Amandina','Amara','Amar�lis','Am�vel','Am�lia','Amelina','Am�rica','Amora',
          'Amorina','Amorzinda','Ana','Anabel','Anabela','Ana�ce','Ana�de','Anair','Ana�s','Anaisa','Ana�sa','Analdina',
          'An�lia','Analice','Analisa','Anamar','Anast�cia','Anatilde','Andrea','Andreia','Andre�na','Andrelina','Andresa',
          '�ndria','An�sia','�ngela','Ang�lica','Angelina','Angelita','�nia','Aniana','An�cia','An�ria','An�sia','Anita',
          'Anquita','Anteia','Antera','Antonela','Ant�nia','Antonieta','Antonina','Anuncia��o','Anunciada','Anuque','Anusca',
          'Aparecida','Apol�nia','Arabela','Araci','Aradna','Argentina','�ria','Ariadna','Ariadne','Ariana','Ariane','Ariele',
          'Arinda','Arlanda','Arlete','Arlinda','Armanda','Armandina','Arm�nia','Arminda','Artemisa','Artem�sia','Aruna','�sia',
          'Asp�sia','Assun��o','Assunta','Astrid','Astride','Atenais','�tina','Audete','Augusta','Aura','�urea','Aur�lia',
          'Aureliana','Aurete','Aurora','Ausenda','Auta','Aux�lia','Ava','Balbina','Baldu�na','B�rbara','B�rbora','Bartolina',
          'Bas�lia','Basilissa','Beanina','Beatriz','Bebiana','Bela','Belarmina','Bel�m','Belina','Belinda','Belisa','Belis�ria',
          'Belmira','Benedita','Ben�cia','Benigna','Benilde','Benita','Benjamina','Benvinda','Bereng�ria','Berenice','Bernadete',
          'Bernarda','Bernardete','B�rnia','Berta','Bertila','Bertilde','Bertina','Bet�nia','B�tia','Betina','Betsab�','Bia','Biana',
          'Bianca','Bibiana','Bina','Bitia','Blandina','Bl�sia','Bonif�cia','Branca','Br�sia','Br�zia','Brena','Brenda','Briana','Brice',
          'Br�cia','Br�gida','Brigite','Briolanja','Briosa','Brites','Brizida','Bruna','Brunilde','C�cia','Cacilda','Caetana','Caia','Calila',
          'Cam�lia','Camila','Candice','C�ndida','C�nia','Carela','C�ren','C�rin','Carina','Carisa','Car�sia','Carissa','C�rita','Carla',
          'Carlinda','Carlota','Carmela','Carm�lia','Carmelina','Carmelinda','Carmelita','C�rmen','Carmezinda','Carmina','Carminda','Carminho',
          'Carmo','Carmorinda','Carol','Carole','Carolina','Carsta','Cassandra','C�ssia','Cassilda','Casta','Castelina','Castorina','Catalina',
          'Catarina','Caterina','C�tia','Catila','Catilina','Cec�lia','Celeste','C�lia','Celina','Celinia','Celsa','Cereja','Ceres','Cesaltina',
          'Ces�ria','Cesarina','Chantal','Cheila','Chema','Cibele','Cid�lia','Cidalina','Cidalisa','Cinara','C�nara','Cinderela','Cinira','C�ntia',
          'Cipora','Circe','C�ria','Cirila','Cizina','Clara','Clarina','Clarinda','Clarinha','Clarisse','Claudemira','Cl�udia','Claudiana','Claudina',
          'Cleia','Cleide','Cl�lia','Clem�ncia','Clementina','Cleodice','Cleonice','Cle�patra','Cl�sia','Cl�cia','Clim�nia','Cl�via','Cloe','Clo�',
          'Clorinda','Clotilde','Colete','Concei��o','Concha','Consola��o','Constan�a','Const�ncia','Consuelo','Cora','Cor�lia','Cord�lia','Corina',
          'C�rita','Corn�lia','Cosete','Cremilda','Cremilde','Crestila','Cris','Cris�lia','Cris�lida','Crisanta','Crisante','Crisna','Cristela',
          'Cristele','Cristene','Cristiana','Cristina','Cristolinda','Cust�dia','Dafne','Dagmar','Daina','Daisi','D�lia','Daliana','Dalida',
          'Dalila','Dalinda','Dalva','D�maris','Dana','D�nia','Daniana','Daniela','Danila','Dara','Darci','Darc�lia','Darlene','Darnela',
          'Davina','Dav�nia','D�bora','D�cia','Deise','Dejanira','Dele','Delfina','D�lia','Deliana','Delisa','Delmina','Delminda','Delmira',
          'Demelza','Dem�ter','Dem�tria','Denisa','Denise','Deodata','Deodete','Deolinda','Deonilde','Deotila','De�tila','Derocila','Diamantina',
          'Diana','D�dia','Didiana','Digna','Diliana','Dilsa','Dina','Din�','Dinamene','Dinarda','Dinarta','Dineia','Dinora','Dione','Dionilde',
          'Dion�sia','Dirce','Dircea','Dircila','Disa','Ditza','Diva','Diza','Djamila','D�lique','Dolores','Domenica','Domingas','Domitila','Domit�lia',
          'Dona','Donatila','Donz�lia','Donz�lia','Dora','Doralice','Dores','Doriana','Dorina','Dorinda','Dorine','D�ris','Dorisa','Doroteia','Drusila',
          'Duartina','Dulce','Dulcelina','Dulc�dia','Dulcina','Dulcineia','D�lia','D�nia','E�rine','Eda','Ed�ria','Edina','Edine','Edite','Edith','Edma',
          'Edmunda','Edna','Eduarda','Eduina','Eglantina','Elana','Elca','Elda','Electra','Eleia','Eleine','Elena','Eleonor','Eleonora','�lia','Eliana',
          'Eliane','El�cia','Eliete','�lin','Elina','Eline','Elisa','Elisabeta','Elisabete','Elisabeth','Elisama','Eliseba','Elisete','El�sia','Elma',
          'Elmira','Elo�','Elodia','El�dia','Eloisa','Elsa','Elsinda','Elu�na','Elva','Elvina','Elvira','Elza','Ema','Emanuela','Em�dia','Em�lia',
          'Emiliana','Encarna��o','Engel�cia','Engr�cia','�nia','Enide','Enilda','�ola','Eponina','Erc�lia','Erica','�rica','Erika','�ris','Ermelinda',
          'Ermengarda','Erm�ria','Ernestina','Ers�lia','Esm�nia','Esmeralda','Esm�ria','Especiosa','Esperan�a','Est�fana','Estef�nia','Estela','Ester',
          'Estrela','Etel','�tel','Etelca','Etelvina','Et�ria','Eudora','Euf�mia','Eug�nia','Eul�lia','Eularina','Eunice','Eurica','Eur�dice','Eut�lia',
          'Eva','Evandra','Evangelina','Evangelista','Evelina','Eveline','�vila','Excelsa','Ezequiela','Laila','Laira','Lais','Lana','Lara','Larissa',
          'La-Salete','Laura','Laureana','Laurina','Laurinda','Laurine','Lav�nia','Lea','Leandra','Leanor','Leena','Leila','L�lia','L�nia','Lenira',
          'Leoc�dia','Leolina','Leom�nia','Leonarda','Leonardina','Leonete','Le�nia','Leonida','Leon�dia','Leonila','Leonilda','Leonilde','Leon�lia',
          'Leonisa','Leonor','Leonora','Leontina','Leopoldina','Leta','Let�cia','Let�zia','Levina','Lia','Liana','Liane','Lianor','Liara','Liberalina',
          'Liberdade','Lib�ria','Libert�ria','L�bia','Lici','L�cia','Lic�nia','L�dia','Lidiana','Lidu�na','Liete','L�gia','Lila','Lil�','L�lia','Lilian',
          'Liliana','Liliane','Liliete','Lilite','Lina','Linda','Lineia','Linete','Lira','Lis','Lisa','Lisana','Lisandra','Lisd�lia','Liseta','Lisete',
          'L�via','Liz','Liz�lia','L�zi','Lizia','L�zie','Loela','Loide','L�lia','Loredana','Lorena','Loreta','Lorina','Lorine','L�tus','Louren�a','Lua',
          'Luamar','Luana','Lub�lia','Luc�lia','Lucelinda','Lucena','Lucete','L�cia','Lucialina','Luciana','Lucileine','Luc�lia','Lucilina','Lucina',
          'Lucinda','Luc�ola','Lucr�cia','Ludmila','Luela','Luena','Lu�sa','Luisete','Luizete','Lumena','Luna','Lurdes','Lurdite','Lusa','Lussinga',
          'Lutgarda','Luz','Luzia','Luzinira','Zacarias','Zaido','Oceano','Octaviano','Oct�vio','Odair','Odeberto','�din','Olavo','Oleg�rio','Ol�mpio',
          'Olindo','Olinto','Olivar','Oliveiros','Oliv�rio','Olivier','Omar','Omer','Ondino','Onildo','Onofre','Orandino','Or�ncio','Orestes','Orlandino',
          'Orlando','Orlindo','Or�sio','�scar','Oseas','Oseias','Osmano','Osmar','Os�rio','Osvaldo','Otac�lio','Otelo','Otniel','Oto','Otoniel','Ov�dio',
          'Eberardo','Eda','Eder','Edgar','�di','�dipo','Edir','Edmero','Edmundo','Edmur','Edo','Eduardo','Eduartino','Edu�no','Edvaldo','Edvino','Egas',
          'Eg�dio','Egil','El�dio','Eleazar','Eleut�rio','Elgar','Eli','Eliab','Eliano','Elias','Eliezer','Eli�zer','�lio','Elioenai','Eliseu','Elisi�rio',
          'El�sio','Elmano','Elmar','Elmer','El�i','Elp�dio','�lsio','�lson','�lton','Elvino','Elze�rio','Elzo','Emanuel','Ema�s','Em�dio','Emiliano','Em�lio',
          'Emo','Eneias','Enes','Engr�cio','Enio','�nio','Enoque','Enrique','Enzo','Erasmo','Erc�lio','Eric','Erico','�rico','Erik','Erique','Ermit�rio','Ern�ni',
          'Ernesto','Esa�','Esmeraldo','Est�cio','Estanislau','Estef�nio','Est�fano','Est�lio','Est�lio','Estev�o','Est�v�o','Euclides','Eufr�sio','Eug�nio','Eul�gio',
          'Eurico','Eus�bio','Eust�cio','Eust�quio','Evaldo','Evandro','Evangelino','Evangelista','Evaristo','Evel�cio','Evel�sio','Ev�lio','Ev�ncio','Everaldo',
          'Everardo','Expedito','Ezequiel'); --30
  
  sexos := SexoList('M', 'M', 'F', 'F', 'F', 
					'F', 'M', 'M', 'M', 'M', 
					'M', 'M', 'F', 'F', 'F', 
					'F', 'F', 'F', 'M', 'M', 
					'M', 'M', 'M', 'M', 'M', 
					'M', 'M', 'F', 'F', 'F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','F',
          'F','F','F','F','F','F','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M','M','M','M','M','M','M',
          'M');
	
  sobrenomes := SobreNomeList('Silva', 'Souza', 'Lima', 'Pereira', 'Fernandes',
                              'Pinheiro', 'Pereira', 'Oliveira', 'Ramos', 'Santos', 
			      'Moreno', 'Mendes', 'Dias', 'Caixeta', 'Nascimento', 
			      'Bittercourt', 'Soares', 'Moureiro', 'Gon�alves', 'Almeida',
			      'Prado', 'Barbosa', 'Neves', 'Freitas', 'Pinto', 
			      'Borges', 'Serra', 'Crespo', 'Carvalho', 'Camargo', 
			      'Guimar�es','Sousa','Fagundes','Falc�o','Faria','Farinha','Fagundes','Ferraz',
                'Ferreira','Ferro','Figueira','Figueiredo','Lima','Luchini','Lacerda','Lopes',
                'Laranjeira','Leal','Le�o','Leit�o','Leite','Leme','Lemos','Lima','Linhares',
                'Lira','Lisboa','Lobato','Liago','Lobo','Lousada','Luz',
                'Macedo','Machado','Maciel','Malory','Madeira','Madruga',
                'Magalh�es','Maia','Marques','Martins','Matos',
                'Marinho','Mariz','Mascarenhas','Medeiros','Meira','Meireles',
                'Melo','Mendon�a','Meneses','Merens','Messias','Mesquita',
                'Pimentel','Miranda','Moita','Moniz','Monjardino',
                'Monteiro','Morais','Moreira','Mota','Moura','Muniz');
 
	dominios := DominioList('gmail.com', 'yahoo.com.br', 'terra.com.br', 'uol.com.br', 
	'fiap.com.br', 'usp.br', 'bol.com.br', 'hotmail.com', 'ig.com.br', 
	'pop.com.br', 'outlook.com.br', 'outlook.com', 'yahoo.com', 'msn.com', 'locaweb.com.br', 
	'globo.com', 'r7.com.br', 'aol.com', 'registro.br', 'metrosp.com.br',
	'prefeitura.sp.gov.br', 'info.abril.com.br', 'petrobras.com.br', 'itau-unibanco.com.br',
	'bradesco.com.br', 'bb.com.br', 'no-ip.com', 'adp.com', 'badoo.com', 'citibank.com.br',
	'microsoft.com.br', 'microsoft.com'); --32

	FOR v_contador IN 1..10000 
	LOOP
        --EXEC DBMS_RANDOM.SEED(TRUNC(DBMS_RANDOM.VALUE(111111111,999999999))); -- melhorar
	       v_random_primeiro := TRUNC(DBMS_RANDOM.VALUE(1,880)); 
         v_random_segundo := TRUNC(DBMS_RANDOM.VALUE(1,97));
		v_insert := 'INSERT INTO CLIENTE 
		(cd_cliente,
     nm_cliente,
		 dt_nasc_cliente,    		
		 ds_sexo,		
		 ds_email,
		 ds_senha,
		 nu_rg_cliente,
     nu_cpf_cliente,
     nu_estrelas
    )
		VALUES
		(sq_cliente.nextval,  
		''' || nomes(v_random_primeiro) || ' ' || sobrenomes(v_random_segundo) || ''', ' ||
		'''' || TO_CHAR(SYSDATE - TRUNC(DBMS_RANDOM.VALUE(15000,45000))) || ''', ''' ||
		sexos(v_random_primeiro) || ''', ''' ||
		lower(nomes(v_random_primeiro)) || '.' || lower(sobrenomes(v_random_segundo)) || '@' || dominios(TRUNC(DBMS_RANDOM.VALUE(1,33))) || ''', ''' ||
		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(10000000000,99999999999))) || ''' , ''' ||
 		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(10,99))) || '.' ||
		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(100,999))) || '.' ||
		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(100,999))) || '-' ||
		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(0,9))) || ''', ''' ||
		TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(100,999))) || '.' ||        	TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(100,999))) || '.' || TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(100,999))) || '-' || TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(01,99))) || ''', ' ||
    TO_CHAR(TRUNC(DBMS_RANDOM.VALUE(1,6))) || ') '; 
    
    --DBMS_OUTPUT.PUT_LINE(v_insert);
    EXECUTE IMMEDIATE v_insert;
	END LOOP;
	EXECUTE IMMEDIATE 'COMMIT';
END;
/


alter table cliente drop (nu_estrelas);
alter table cliente drop (ds_senha);