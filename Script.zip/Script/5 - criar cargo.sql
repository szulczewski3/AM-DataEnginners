insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'PRESIDENTE');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'DIRETOR FINANCEIRO');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, ' GERENTE GERAL');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'GERENTE DE LOJA');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'GAR�OM');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'CAIXA');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'RECEPCIONISTA');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'AUX DE LIMPEZA');

insert into cargo (cd_cargo, nm_cargo) 
values (SQ_CARGO.NEXTVAL, 'TELEFONISTA');

